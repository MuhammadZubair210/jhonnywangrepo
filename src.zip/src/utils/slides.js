export default slides = [
  {
    key: '1',
    heading: 'Messages',
    title:
      'A veteran poker pro and a poker-playing lawyer have resolved a Florida-based disp…',
    image: require('../assets/welcome1.png'),
  },
  {
    key: '3',
    heading: 'Messages',
    title:
      'A veteran poker pro and a poker-playing lawyer have resolved a Florida-based disp…',
    image: require('../assets/welcome3.png'),
  },
  {
    key: '2',
    heading: 'Messages',
    title:
      'A veteran poker pro and a poker-playing lawyer have resolved a Florida-based disp…',
    image: require('../assets/welcome2.png'),
  },

  {
    key: '4',
    heading: 'Messages',
    title:
      'A veteran poker pro and a poker-playing lawyer have resolved a Florida-based disp…',
    image: require('../assets/welcome4.png'),
  },
];
